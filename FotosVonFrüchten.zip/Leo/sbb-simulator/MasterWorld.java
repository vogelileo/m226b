import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MasterWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MasterWorld extends World
{
    public WorldController worldController;
    /**
     * Constructor for objects of class MasterWorld.
     * 
     */
    public MasterWorld()
    {    
        super(800, 450, 1); 
        
        
    }
    
    
    
}
